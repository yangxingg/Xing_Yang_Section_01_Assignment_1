package Cloud.ApacheLog;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.util.*;  
import org.apache.hadoop.conf.*; 
/**
 * Counts all of the hits for an ip. Outputs all ip's
 */
public class IpReducer2 extends MapReduceBase implements Reducer<IntWritable,Text,  Text, IntWritable> 
{

  // private Text result = new Text();

  public void reduce( IntWritable counts, Iterator<Text> ip,
      OutputCollector<Text, IntWritable> output, Reporter reporter)
      throws IOException {
    
    while (ip.hasNext())
    {
      //result.set(ip.next().get());
    	int outCount = 0- Integer.parseInt(String.valueOf(counts));
      output.collect(ip.next(), new IntWritable(outCount));
    }
    


}
}