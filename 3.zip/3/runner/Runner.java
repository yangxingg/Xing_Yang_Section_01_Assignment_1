package Cloud.ApacheLog;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.util.*;  
import org.apache.hadoop.conf.*; 

import java.util.*;

public class Runner {

  /**
   * @param args
   */
  public static void main(String[] args) throws Exception
  {
        JobConf conf = new JobConf(Runner.class);
        conf.setJobName("ip-count");
        
        conf.setMapperClass(IpMapper.class);
        
        conf.setMapOutputKeyClass(Text.class);
        conf.setMapOutputValueClass(IntWritable.class);
        
        conf.setReducerClass(IpReducer.class);
        
        
        // take the input and output from the command line
        FileInputFormat.setInputPaths(conf, new Path(args[0]));
        FileOutputFormat.setOutputPath(conf, new Path(args[1]));


        JobConf conf1 = new JobConf(Runner.class);
        conf1.setJobName("ip-count");
        
        conf1.setMapperClass(IpMapper2.class);
        
        //conf1.setMapOutputKeyClass(Text.class);
        //conf1.setMapOutputValueClass(IntWritable.class);
        conf1.setMapOutputKeyClass(IntWritable.class);
        conf1.setMapOutputValueClass(Text.class);

        
        conf1.setReducerClass(IpReducer2.class);
        
        
        // take the input and output from the command line
        FileInputFormat.setInputPaths(conf1, new Path(args[1]));
        FileOutputFormat.setOutputPath(conf1, new Path(args[2]));




        JobClient.runJob(conf);
        JobClient.runJob(conf1);

  }

}
