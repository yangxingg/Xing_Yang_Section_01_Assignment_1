﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{

    class Program
    {
        
        // Here we define a new type called D that is a "transformation" type over integers:
        delegate bool D(int i);

        static void Main(string[] args)
        {
           // Hello! Here we create a list of string:
            List<string> list = new List<string>();

            // Here we add a few items:
            
          //  Console.WriteLine("Hit RETURN to generate the prime numbers transofmration..");
            //Console.ReadLine();
            var primeNum = Unfold3(2, i => i + 2);
            Console.WriteLine("Press enter to see first 20 prime number:");
            Console.WriteLine(primeNum);

            Console.WriteLine("first 20 prime Number:");

            Console.ReadLine();
            foreach (var x in primeNum.Take(20))
            {
                Console.WriteLine(x);
            }
            Console.WriteLine("Press enter to see he 10001st prime number:");
            Console.ReadLine();

            foreach (var x in primeNum.Skip(10000).Take(1))
            {
                Console.WriteLine(x);
            }



            Console.WriteLine("Hit RETURN to build the fibonacci transformation..");
            Console.ReadLine();
            var fibonacci = Unfold2(1, (a, b) => a + b);

            Console.ReadLine();
            foreach (var x in fibonacci.Take(20))
            {
                Console.WriteLine(x);
            }
            Console.ReadLine();

            Console.ReadLine();

            // bye bye :-)
        }

        // Wow, i'm really far away to where all the action is :-(
        

        static bool IsPrime(Int64 p)
        {
            if (p == 1) return false;
            if (p == 2) return true;
            if (p == 3 || p == 5) return true;
            if (p == 7 ) return true;
            if (p % 2 == 0) return false;
            Int64 max = (Int64)Math.Ceiling(Math.Sqrt(p));
            for (Int64 divisor = 3; divisor <= max; divisor += 2)
            {
                if (p % divisor == 0) return false;
            }
            return true;
        }


        private static IEnumerable<T> Unfold3<T>(T test, Func<T, T> accumulator)
        {
            var value = test;
           
            while (true)
            {
                if (IsPrime(Convert.ToInt64(value)))
                {
                    yield return value;
                }
                if (Convert.ToUInt64(value) == 2)
                {

                    value = (T)Convert.ChangeType(3, typeof(T));



                }
                else
                {
                    value = accumulator(value);
                }
                
                   // value = accumulator(value);
                
            }
        }


        // [][] natural numbers transformation (coroutine)
        private static IEnumerable<T> Unfold<T>(T seed, Func<T, T> accumulator)
        {
            var nextValue = seed;
            while (true)
            {
                yield return nextValue;
                nextValue = accumulator(nextValue);
            }
        }

        // [][] fibonacci numbers transofmration (coroutine)
        private static IEnumerable<T> Unfold2<T>(T seed, Func<T,T,T> accumulator)
        {
            var a =  seed;
            var b = seed;
            T c;
            while (true)
            {
                
                if (IsPrime(Convert.ToInt64(b)))
                {
                    yield return (T)Convert.ChangeType(b, typeof(T));
                }
                c = (T)Convert.ChangeType(b, typeof(T));
               
                b = accumulator
                    (a,b);
                a = c;
            }
        }


    }
}
