﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {

        static void ShowVector(double[] vector, int decimals, int valsPerRow, bool newLine)
        {
            for (int i = 0; i < vector.Length; ++i)
            {
                if (i % valsPerRow == 0) Console.WriteLine("");
                Console.Write(vector[i].ToString("F" + decimals).PadLeft(decimals + 4) + " ");
            }
            if (newLine == true) Console.WriteLine("");
        }

        static void ShowMatrix(int[][] matrix, int numRows, bool indices)
        {
            for (int i = 0; i < numRows; ++i)
            {
                if (indices == true)
                    Console.Write("[" + i.ToString().PadLeft(2) + "]   ");
                for (int j = 0; j < matrix[i].Length; ++j)
                {
                    Console.Write(matrix[i][j] + " ");
                }
                Console.WriteLine("");
            }
            int lastIndex = matrix.Length - 1;
            if (indices == true)
                Console.Write("[" + lastIndex.ToString().PadLeft(2) + "]   ");
            for (int j = 0; j < matrix[lastIndex].Length; ++j)
                Console.Write(matrix[lastIndex][j] + " ");
            Console.WriteLine("\n");
        }

        //----------------------------------3-----------------

        static void MakeTrainTest(int[][] data, int seed, out int[][] trainData, out int[][] testData)
        {
            Random rnd = new Random(seed);
            int totRows = data.Length; // compute number of rows in each result
            int numTrainRows = (int)(totRows * 0.8);
            int numTestRows = totRows - numTrainRows;
            trainData = new int[numTrainRows][];
            testData = new int[numTestRows][];

            int[][] copy = new int[data.Length][]; // make a copy of data
            for (int i = 0; i < copy.Length; ++i)  // by reference to save space
                copy[i] = data[i];
            for (int i = 0; i < copy.Length; ++i) // scramble row order of copy
            {
                int r = rnd.Next(i, copy.Length);
                int[] tmp = copy[r];
                copy[r] = copy[i];
                copy[i] = tmp;
            }
            for (int i = 0; i < numTrainRows; ++i) // create training
                trainData[i] = copy[i];

            for (int i = 0; i < numTestRows; ++i) // create test
                testData[i] = copy[i + numTrainRows];
        } // MakeTrainTest



        static void Main(string[] args)
        {

            //int[][] data = new int[100][];

          
            //----------------------------------------------------


            string[] lines = System.IO.File.ReadAllLines(@"Datasetnew.txt");
      
            int[][] data = new int[lines.Length][];
            System.Console.WriteLine("Contents of Dataset.txt = ");
            
            Console.WriteLine(lines.Length);

            for (int i = 0; i < lines.Length; i++) {
           
                string[] lineSet = lines[i].Split(',');
                
                int len = lineSet.Length;
                data[i] = new int[len];
                for (int j = 0; j < len; j++) {
                     data[i ][j] = Int32.Parse(lineSet[j]);
                }
            }



            //Console.WriteLine("Press any key to exit.");
            //System.Console.ReadKey();




            //----------------------------------------

            Console.WriteLine("\nFirst few lines and last of all data are: \n");
            ShowMatrix(data, 4, true);




            //------------------------------------3--
            Console.WriteLine("\nSplitting data into 80% train" + " and 20% test matrices");
            int[][] trainData = null;
            int[][] testData = null;
            MakeTrainTest(data, 0, out trainData, out testData);

            Console.WriteLine("\nEncoding 'n' and '?' = 0, 'y' = 1, 'democrat' = 0, 'republican' = 1");
            Console.WriteLine("Moving political party to last column");
            Console.WriteLine("\nFirst few rows and last of training data are:\n");
            ShowMatrix(trainData, 3, true);

            //-------------------------------------

            Console.WriteLine("\nBegin training using Winnow algorithm");
            int numInput = 16;
            Winnow w = new Winnow(numInput, 0); // rndSeed = 0
            double[] weights = w.TrainWeights(trainData);
            Console.WriteLine("Training complete");

            Console.WriteLine("\nFinal model weights are:");
            ShowVector(weights, 4, 8, true);

            //-------------------------------------------------

            double trainAcc = w.Accuracy(trainData);
            double testAcc = w.Accuracy(testData);

            Console.WriteLine("\nPrediction accuracy on training data = " + trainAcc.ToString("F4"));
            Console.WriteLine("Prediction accuracy on test data = " + testAcc.ToString("F4"));

            //---------------------------------------------
            
                    Console.WriteLine("\nPredicting a mushroom that has bell cap shape, fibrous cp-surface, brown cap-color, bruises , almod odor, attached of gill attachment,close gill spacing and board gill size, gill color:black, stalk-shapr:enlarging, stalk-surface-abovering:fibrous, stalk-surface-below-ring:fibrous, stalk-color:brown,veil-type:brown, population is abundanu and grasses, can this ediable?");

                      int[] yays = new int[] { 1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,1,0,0,0,1,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0};

                      int predicted = w.ComputeY(yays);

                      if (predicted == 0)

                          Console.WriteLine("Prediction is not 'ediable'");

                      else

                          Console.WriteLine("Prediction is 'edible'");



            /*   Console.WriteLine("\nPredicting party of Representative with all 'no' votes");

               int[] nays = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
               int predicted2 = w.ComputeY(nays);

               if (predicted2 == 0)

                   Console.WriteLine("Prediction is 'democrat'");

               else

                   Console.WriteLine("Prediction is 'republican'");



               Console.WriteLine("\nEnd Winnow demo\n");
               */
        }
    }
}
