/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datasethandle;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author yangxing
 */
public class DataSetHandle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         try {
            FileReader reader = new FileReader("data.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);
 
            String line;
 
             FileWriter writer = new FileWriter("Dataset.txt", true);
            
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
                Mushroom ma = new Mushroom();
                String[] res = ma.getProper();
                String[] data = line.split(",");
                if(data[0].equals("e"))
                      res[122] = "1";
                else
                      res[122] = "0";
                
                //--------------1
                if(data[1].equals("b")){
                       res[0] = "1";
                 }else if(data[1].equals("c")){
                       res[1] = "1";
                 }else if(data[1].equals("x")){
                       res[2] = "1";
                 }else if(data[1].equals("f")){
                       res[3] = "1";
                 }else if(data[1].equals("k")){
                       res[4] = "1";
                 }else if(data[1].equals("s")){
                       res[5] = "1";
                 }
                
                //----------------2
                
                if(data[2].equals("f")){
                       res[6] = "1";
                 }else if(data[2].equals("g")){
                       res[7] = "1";
                 }else if(data[2].equals("y")){
                       res[8] = "1";
                 }else if(data[2].equals("s")){
                       res[9] = "1";
                 }
                
                //--------------------3
                
                if(data[3].equals("n")){
                       res[10] = "1";
                 }else if(data[3].equals("b")){
                       res[11] = "1";
                 }else if(data[3].equals("c")){
                       res[12] = "1";
                 }else if(data[3].equals("g")){
                       res[13] = "1";
                 }else if(data[3].equals("r")){
                       res[14] = "1";
                 }else if(data[3].equals("p")){
                       res[15] = "1";
                 }else if(data[3].equals("u")){
                       res[16] = "1";
                 }else if(data[3].equals("e")){
                       res[17] = "1";
                 }else if(data[3].equals("w")){
                       res[18] = "1";
                 }else if(data[3].equals("y")){
                       res[19] = "1";
                 }
                
                
                //-----------------4
                
                if(data[4].equals("t")){
                       res[20] = "1";
                 }else{
                     res[20] = "0";
                }
                
                //--------------------5
                
                 if(data[5].equals("a")){
                       res[21] = "1";
                 }else if(data[5].equals("l")){
                       res[22] = "1";
                 }else if(data[5].equals("c")){
                       res[23] = "1";
                 }else if(data[5].equals("y")){
                       res[24] = "1";
                 }else if(data[5].equals("f")){
                       res[25] = "1";
                 }else if(data[5].equals("m")){
                       res[26] = "1";
                 }else if(data[5].equals("n")){
                       res[27] = "1";
                 }else if(data[5].equals("p")){
                       res[28] = "1";
                 }else if(data[5].equals("s")){
                       res[29] = "1";
                 }
                
                
                 //-------------------6
                 
                 
                  if(data[6].equals("a")){
                       res[30] = "1";
                 }else if(data[6].equals("d")){
                       res[31] = "1";
                 }else if(data[6].equals("f")){
                       res[32] = "1";
                 }else if(data[6].equals("n")){
                       res[33] = "1";
                 }
                 
                 //--------------------7
                  
                  if(data[7].equals("c")){
                       res[34] = "1";
                 }else if(data[7].equals("w")){
                       res[35] = "1";
                 }else if(data[7].equals("d")){
                       res[36] = "1";
                 }
                 
                 
                 //-------------------8
                  
                  if(data[8].equals("b")){
                       res[37] = "1";
                 }else{
                       res[37] = "0";
                 }
                 
                 //-----------------------9
                  
                  
                  if(data[9].equals("k")){
                       res[38] = "1";
                 }else if(data[9].equals("n")){
                       res[39] = "1";
                 }else if(data[9].equals("b")){
                       res[40] = "1";
                 }else if(data[9].equals("h")){
                       res[41] = "1";
                 }else if(data[9].equals("g")){
                       res[42] = "1";
                 }else if(data[9].equals("r")){
                       res[43] = "1";
                 }else if(data[9].equals("o")){
                       res[44] = "1";
                 }else if(data[9].equals("p")){
                       res[45] = "1";
                 }else if(data[9].equals("u")){
                       res[46] = "1";
                 }else if(data[9].equals("e")){
                       res[47] = "1";
                 }else if(data[9].equals("w")){
                       res[48] = "1";
                 }else if(data[9].equals("y")){
                       res[49] = "1";
                 }
                  
                  
                  
               //----------------------10
                 if(data[10].equals("e")){
                       res[50] = "1";
                 }else {
                       res[50] = "0";
                 }
               //-----------------------11
                 
                 if(data[11].equals("b")){
                       res[51] = "1";
                 }else if(data[11].equals("c")){
                       res[52] = "1";
                 }else if(data[11].equals("u")){
                       res[53] = "1";
                 }else if(data[11].equals("e")){
                       res[54] = "1";
                 }else if(data[11].equals("z")){
                       res[55] = "1";
                 }else if(data[11].equals("r")){
                       res[56] = "1";
                 }else if(data[11].equals("?")){
                       res[57] = "1";
                 }
                  
                 //----------------------12
                 
                 
                 if(data[12].equals("f")){
                       res[58] = "1";
                 }else if(data[12].equals("y")){
                       res[59] = "1";
                 }else if(data[12].equals("k")){
                       res[60] = "1";
                 }else if(data[12].equals("s")){
                       res[61] = "1";
                 }
                 
                 
                //-------------------------13
                 
                 if(data[13].equals("f")){
                       res[62] = "1";
                 }else if(data[13].equals("y")){
                       res[63] = "1";
                 }else if(data[13].equals("k")){
                       res[64] = "1";
                 }else if(data[13].equals("s")){
                       res[65] = "1";
                 }
                 
                 
                 //-------------------------14
                 
                 
                  if(data[14].equals("n")){
                       res[66] = "1";
                 }else if(data[14].equals("b")){
                       res[67] = "1";
                 }else if(data[14].equals("c")){
                       res[68] = "1";
                 }else if(data[14].equals("g")){
                       res[69] = "1";
                 }else if(data[14].equals("o")){
                       res[70] = "1";
                 }else if(data[14].equals("p")){
                       res[71] = "1";
                 }else if(data[14].equals("e")){
                       res[72] = "1";
                 }else if(data[14].equals("w")){
                       res[73] = "1";
                 }else if(data[14].equals("y")){
                       res[74] = "1";
                 }
                 
                 //------------------------15
                  
                  if(data[15].equals("n")){
                       res[75] = "1";
                 }else if(data[15].equals("b")){
                       res[76] = "1";
                 }else if(data[15].equals("c")){
                       res[77] = "1";
                 }else if(data[15].equals("g")){
                       res[78] = "1";
                 }else if(data[15].equals("o")){
                       res[79] = "1";
                 }else if(data[15].equals("p")){
                       res[80] = "1";
                 }else if(data[15].equals("e")){
                       res[81] = "1";
                 }else if(data[15].equals("w")){
                       res[82] = "1";
                 }else if(data[15].equals("y")){
                       res[83] = "1";
                 }
                 
                 
                 //--------------------------16
                  
                  if(data[16].equals("p")){
                       res[84] = "1";
                 }else{
                       res[84] = "0";
                 }
                  //---------------------------17
                  
                  if(data[17].equals("n")){
                       res[85] = "1";
                 }else if(data[17].equals("o")){
                       res[86] = "1";
                 }else if(data[17].equals("w")){
                       res[87] = "1";
                 }else if(data[17].equals("y")){
                       res[88] = "1";
                 }
                  
                 //-------------------------18
                  
                   if(data[18].equals("n")){
                       res[89] = "1";
                 }else if(data[18].equals("o")){
                       res[90] = "1";
                 }else if(data[18].equals("t")){
                       res[91] = "1";
                 }
                   
                  //------------------------19
                   
                   if(data[19].equals("c")){
                       res[92] = "1";
                 }else if(data[19].equals("e")){
                       res[93] = "1";
                 }else if(data[19].equals("f")){
                       res[94] = "1";
                 }else if(data[19].equals("l")){
                       res[95] = "1";
                 }else if(data[19].equals("n")){
                       res[96] = "1";
                 }else if(data[19].equals("p")){
                       res[97] = "1";
                 }else if(data[19].equals("s")){
                       res[98] = "1";
                 }else if(data[19].equals("z")){
                       res[99] = "1";
                 }
                   
                  //---------------------20
                   
                 if(data[20].equals("k")){
                       res[100] = "1";
                 }else if(data[20].equals("n")){
                       res[101] = "1";
                 }else if(data[20].equals("b")){
                       res[102] = "1";
                 }else if(data[20].equals("h")){
                       res[103] = "1";
                 }else if(data[20].equals("r")){
                       res[104] = "1";
                 }else if(data[20].equals("o")){
                       res[105] = "1";
                 }else if(data[20].equals("u")){
                       res[106] = "1";
                 }else if(data[20].equals("w")){
                       res[107] = "1";
                 }else if(data[20].equals("y")){
                       res[108] = "1";
                 } 
                   
                  //-----------------------21 
                   if(data[21].equals("a")){
                       res[109] = "1";
                 }else if(data[21].equals("c")){
                       res[110] = "1";
                 }else if(data[21].equals("n")){
                       res[111] = "1";
                 }else if(data[21].equals("s")){
                       res[112] = "1";
                 }else if(data[21].equals("v")){
                       res[113] = "1";
                 }else if(data[21].equals("y")){
                       res[114] = "1";
                 }
                   
                 //------------------------22
                   
                    if(data[22].equals("g")){
                       res[115] = "1";
                 }else if(data[22].equals("l")){
                       res[116] = "1";
                 }else if(data[22].equals("m")){
                       res[117] = "1";
                 }else if(data[22].equals("p")){
                       res[118] = "1";
                 }else if(data[22].equals("u")){
                       res[119] = "1";
                 }else if(data[22].equals("w")){
                       res[120] = "1";
                 }else if(data[22].equals("d")){
                       res[121] = "1";
                 }
                   
//                 for(String s : res) 
//                       System.out.print(s + "-");
                    
                
                   for(int i = 0 ; i < res.length; i++){
                       if(i == (res.length - 1))
                           writer.write(res[i]);
                       else
                            writer.write(res[i]+",");
                   }
                   writer.write("\r\n");  
                   
                    
             }
            writer.close();
              reader.close();
 
            
         
                
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        
    }
    
}
