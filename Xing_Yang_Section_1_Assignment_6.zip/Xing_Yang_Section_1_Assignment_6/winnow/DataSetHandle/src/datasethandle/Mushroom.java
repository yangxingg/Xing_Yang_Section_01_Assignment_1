/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datasethandle;

/**
 *
 * @author yangxing
 */
public class Mushroom {
    private String[] proper = new String[123];
 
    
    
    
    
    
    public Mushroom() {
     for(int i = 0; i < proper.length; i++)
           proper[i] = "0";
           
       
    }

    public String[] getProper() {
        return proper;
    }

    public void setProper(String[] proper) {
        this.proper = proper;
    }
    
    
    
}
