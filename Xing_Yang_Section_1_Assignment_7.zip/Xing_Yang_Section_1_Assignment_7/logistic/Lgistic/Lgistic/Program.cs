﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logistic
{
    class Program
    {


        // generate artificial observations
        static double[][] MakeAllData(int numFeatures, int numRows, int seed)
        {
            Random rnd = new Random(seed);

            // numfeatures weights (bills)
            double[] weights = new double[numFeatures + 1]; // inc. b0
            for (int i = 0; i < weights.Length; ++i)
                weights[i] = 20.0 * rnd.NextDouble() - 10.0; // [-10.0 to +10.0]

            // numRows observations (congressmen voting on each bill) 
            // Last column reserved for label, which is categorical binary
            double[][] result = new double[numRows][]; // allocate matrix
            for (int i = 0; i < numRows; ++i)
                result[i] = new double[numFeatures + 1]; // Y in last column

            // generate random observations
            for (int i = 0; i < numRows; ++i) // for each row
            {
                double y = weights[0]; // the b0 
                for (int j = 0; j < numFeatures; ++j) // each feature / column except last
                {
                    double x = 20.0 * rnd.NextDouble() - 10.0; // random X in [10.0, +10.0]
                    result[i][j] = x; // store x

                    double wx = x * weights[j + 1]; // weight * x 
                    y += wx; // accumulate to get Y
                    // now add some noise
                    y += numFeatures * rnd.NextDouble();
                }
                if (y > numFeatures) // because the noise was +, make it harder to be a 1
                    result[i][numFeatures] = 1.0; // store y in last column
                else
                    result[i][numFeatures] = 0.0;
            }
            Console.WriteLine("Data generation weights:");
            ShowVector(weights, 4, 10, true);

            Console.WriteLine("\nFirst few lines of all data are (last column is the label): \n");
            ShowMatrix(result, 4, 4, true);

            return result;
        }

        //------------------------------6

        static void MakeTrainTest(double[][] allData, int seed, out double[][] trainData, out double[][] testData)
        {
            Random rnd = new Random(seed);
            int totRows = allData.Length;
            int numTrainRows = (int)(totRows * 0.80); // 80% hard-coded
            int numTestRows = totRows - numTrainRows;
            trainData = new double[numTrainRows][];
            testData = new double[numTestRows][];

            double[][] copy = new double[allData.Length][]; // ref copy of all data
            for (int i = 0; i < copy.Length; ++i)
                copy[i] = allData[i];

            for (int i = 0; i < copy.Length; ++i) // scramble order
            {
                int r = rnd.Next(i, copy.Length); // use Fisher-Yates
                double[] tmp = copy[r];
                copy[r] = copy[i];
                copy[i] = tmp;
            }
            for (int i = 0; i < numTrainRows; ++i)
                trainData[i] = copy[i];

            for (int i = 0; i < numTestRows; ++i)
                testData[i] = copy[i + numTrainRows];
        }

        //------------------------11
        public static void ShowVector(double[] vector, int decimals, int lineLen, bool newLine)
        {
            for (int i = 0; i < vector.Length; ++i)
            {
                if (i > 0 && i % lineLen == 0) Console.WriteLine("");
                if (vector[i] >= 0) Console.Write(" ");
                Console.Write(vector[i].ToString("F" + decimals) + " ");
            }
            if (newLine == true)
                Console.WriteLine("");
        }

        static void ShowMatrix(double[][] matrix, int numRows, int decimals, bool indices)
        {
            for (int i = 0; i < numRows; ++i)
            {
                if (indices == true)
                    Console.Write("[" + i.ToString().PadLeft(2) + "]   ");
                for (int j = 0; j < matrix[i].Length; ++j)
                {
                    Console.Write(matrix[i][j].ToString("F" + decimals) + " ");
                }
                Console.WriteLine("");
            }
            int lastIndex = matrix.Length - 1;
            if (indices == true)
                Console.Write("[" + lastIndex.ToString().PadLeft(2) + "]   ");
            for (int j = 0; j < matrix[lastIndex].Length; ++j)
                Console.Write(matrix[lastIndex][j].ToString("F" + decimals) + " ");
            Console.WriteLine("\n");
        }








        static void Main(string[] args)
        {
            //----------------------------------2


            int numFeatures = 122;
         
         //   int numRows = 1000;
            int seed = 42;  // interesting seeds: 28, 32, (42), 56, 58, 63, 91

            // generate artificial observations
            //Console.WriteLine("\nGenerating " + numRows +
            //  " artificial data items with " + numFeatures + " features");

            string[] lines = System.IO.File.ReadAllLines(@"Result1.txt");

            double[][] allData = new double[lines.Length][];
            System.Console.WriteLine("Contents of Dataset.txt = ");
            int numRows = lines.Length;
            Console.WriteLine(lines.Length);

            for (int i = 0; i < lines.Length; i++)
            {

                string[] lineSet = lines[i].Split(',');

                int len = lineSet.Length;
                allData[i] = new double[len];
                for (int j = 0; j < len; j++)
                {
                    allData[i][j] = Int32.Parse(lineSet[j]);
                }
            }

    





            
            //double[][] allData = MakeAllData(numFeatures, numRows, seed);


            //--------------------------3
            // instantiate logistic binary classifier
            Console.WriteLine("Creating LR binary classifier..");
            LogisticClassifier lc = new LogisticClassifier(numFeatures);


            //-----------------------7
            Console.WriteLine("Creating train (80%) and test (20%) matrices after scrambling observations order..");
            double[][] trainData;
            double[][] testData;
            MakeTrainTest(allData, 0, out trainData, out testData);
            Console.WriteLine("Done");
            Console.WriteLine("\nTraining data: \n");
            ShowMatrix(trainData, 4, 2, true);
            Console.WriteLine("\nTest data: \n");
            ShowMatrix(testData, 3, 2, true);



            //-------------------1
            Console.WriteLine("\nSeeking good L1 weight");
            double alpha1 = lc.FindGoodL1Weight(trainData, seed);
            Console.WriteLine("Good L1 weight = " + alpha1.ToString("F3"));

            Console.WriteLine("\nSeeking good L2 weight");
            double alpha2 = lc.FindGoodL2Weight(trainData, seed);
            Console.WriteLine("Good L2 weight = " + alpha2.ToString("F3"));


            //----------------------10

            // train using no regularization
            int maxEpochs = 1000;
            Console.WriteLine("\nStarting training using no regularization..");
            double[] weights = lc.TrainWeights(trainData, maxEpochs, seed, 0.0, 0.0);

            Console.WriteLine("\nBest weights found:");
            ShowVector(weights, 3, weights.Length, true);

            double trainAccuracy = lc.Accuracy(trainData, weights);
            Console.WriteLine("Prediction accuracy on training data = " + trainAccuracy.ToString("F4"));

            double testAccuracy = lc.Accuracy(testData, weights);
            Console.WriteLine("Prediction accuracy on test data = " + testAccuracy.ToString("F4"));







            //-------------------------8
            // train using L1 regularization
            Console.WriteLine("\nStarting training using L1 regularization, alpha1 = " + alpha1.ToString("F3"));
            weights = lc.TrainWeights(trainData, maxEpochs, seed, alpha1, 0.0);

            Console.WriteLine("\nBest weights found:");
            ShowVector(weights, 3, weights.Length, true);

            trainAccuracy = lc.Accuracy(trainData, weights);
            Console.WriteLine("Prediction accuracy on training data = " + trainAccuracy.ToString("F4"));

            testAccuracy = lc.Accuracy(testData, weights);
            Console.WriteLine("Prediction accuracy on test data = " + testAccuracy.ToString("F4"));


            //-------------------------------9
            // train using L2 regularization
            Console.WriteLine("\nStarting training using L2 regularization, alpha2 = " + alpha2.ToString("F3"));
            weights = lc.TrainWeights(trainData, maxEpochs, seed, 0.0, alpha2);

            Console.WriteLine("\nBest weights found:");
            ShowVector(weights, 3, weights.Length, true);

            trainAccuracy = lc.Accuracy(trainData, weights);
            Console.WriteLine("Prediction accuracy on training data = " + trainAccuracy.ToString("F4"));

            testAccuracy = lc.Accuracy(testData, weights);
            Console.WriteLine("Prediction accuracy on test data = " + testAccuracy.ToString("F4"));

            Console.WriteLine("\nEnd Regularization demo\n");
            Console.ReadLine();

             }



        


    }
}
